from flask import Flask, render_template, request, url_for, redirect, session, flash
from datetime import timedelta

app = Flask(__name__)
app.secret_key = "Hello"
app.permanent_session_lifetime = timedelta(minutes=5)

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/test")
def new_home():
    return render_template('test.html')

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        session.permanent = True
        us = request.form["nm"]
        session["user"] = us
        return redirect(url_for("user_1"))
    else:
        if "user" in session:
            # Redirect to user_1 if already logged in
            return redirect(url_for("user_1"))
        # Otherwise, render login page
        return render_template('login.html')

@app.route("/user_l")
def user_1():
    if "user" in session:
        usr = session["user"]
        return f"<h1>{usr}</h1>"
    else:
        return redirect(url_for('login'))

@app.route("/logout")
def logout():
    if "user" in session:
        user = session["user"]
        flash(f"You have been logged out, {user}", "info")
        session.pop("user", None)
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
